Click "setup.exe" or "PrincessAndDragon.application" file to install this game.

After install the game, click "PrincessAndDragon.application" to play this game.

Once you istall, DO NOT move the files to other place. 
You may need to move the files back to installed Directory or Uninstall to play the game again.
